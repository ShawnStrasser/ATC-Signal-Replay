# Signal-Replay

**Replay historical signal controller events to test controllers for bug replication, software validation, and behavior comparison.**

Signal-Replay reads high-resolution (hi-res) event logs from traffic signal controllers and replays detector actuations back to test controllers via NTCIP/SNMP. It automatically detects phase conflicts, compares controller behavior across runs, and stores all results in a queryable DuckDB database.

## Features

- **Event Replay** — Convert hi-res logs to NTCIP detector calls and send to any ATC controller
- **Conflict Detection** — Virtual conflict monitor checks for incompatible phase/overlap combinations
- **Run Comparison** — DTW (Dynamic Time Warping) analysis to compare phase sequences and timing
- **Multi-Signal Support** — Replay multiple coordinated intersections in parallel
- **Speed Control** — Run simulations faster than real-time for rapid testing
- **DuckDB Storage** — Query events, conflicts, and comparisons with SQL

## Installation

```bash
pip install signal-replay
```

## Quick Start

```python
import signal_replay as sr

# Define signal configuration
signal = sr.SignalConfig(
    device_id='test_intersection',
    ip='127.0.0.1',
    udp_port=1025,  # Required for localhost
    events='path/to/events.csv'
)

# Create and run simulation
config = sr.SimulationConfig(
    signals=[signal],
    simulation_replays=3,
    db_path='./results.duckdb'
)

sim = sr.ATCSimulation(config, debug=True)
results = sim.run()

print(f"Completed: {results['completed_runs']}")
print(f"Conflicts: {len(results['conflicts'])}")
```

## Configuration Reference

### SignalConfig

Defines a single signal/intersection to replay.

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `device_id` | str | Yes | — | Unique identifier for the signal |
| `ip` | str | Yes | — | Controller IP address |
| `events` | DataFrame/Path | Yes | — | Hi-res event data (CSV, Parquet, DataFrame, or Arrow Table) |
| `udp_port` | int | Conditional | 161 | SNMP port. **Required when `ip` is localhost/127.0.0.1** |
| `cycle_length` | int | No | 0 | Cycle length in seconds. Set to coordinate replay start with cycle boundaries. `0` = no coordination |
| `cycle_offset` | float | No | 0.0 | Seconds into the cycle to start replay (use with `cycle_length` for offset coordination) |
| `incompatible_pairs` | list | No | None | Phase/overlap pairs to monitor for conflicts. If omitted, conflict checking is disabled |
| `http_port` | int/None | No | Auto | Port for HTTP log collection. Defaults to `udp_port` for localhost, `80` for remote. `None` disables collection |
| `limit_minutes` | float | No | 0.0 | Only replay the last N minutes of events. `0` = replay all |
| `buffer_minutes` | float | No | 0.0 | When using `limit_minutes`, include this many extra minutes of lead-in events for context |

### SimulationConfig

Global settings for the simulation run.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `signals` | list | — | List of `SignalConfig` objects (required) |
| `simulation_replays` | int | 1 | Number of times to replay the event sequence |
| `stop_on_conflict` | bool | False | Stop immediately when a conflict is detected |
| `db_path` | str | `./atc_replay.duckdb` | Path to DuckDB database for storing results |
| `simulation_speed` | float | 1.0 | Speed multiplier (e.g., `2.0` = 2x real-time) |
| `collection_interval_minutes` | float | 5.0 | How often to poll controller for output events |

## Examples

### Conflict Detection

To detect conflicts, define which phase/overlap pairs should never be active simultaneously:

```python
import signal_replay as sr

signal = sr.SignalConfig(
    device_id='intersection_1',
    ip='127.0.0.1',
    udp_port=1025,
    events='events.csv',
    incompatible_pairs=[
        ('Ph1', 'Ph5'), ('Ph2', 'Ph6'),
        ('Ph3', 'Ph7'), ('Ph4', 'Ph8'),
        ('O1', 'Ph5'),  # Overlap vs phase
    ]
)

config = sr.SimulationConfig(
    signals=[signal],
    simulation_replays=10,
    stop_on_conflict=True
)

sim = sr.ATCSimulation(config)
results = sim.run()

if results['conflicts']:
    print("Conflicts detected!")
    for c in results['conflicts']:
        print(f"  {c['timestamp']}: {c['conflict_details']}")
```

### Multi-Signal Coordinated Replay

For coordinated intersections, set matching `cycle_length` values. Use `cycle_offset` if signals are offset from each other:

```python
import signal_replay as sr

signals = [
    sr.SignalConfig(
        device_id='main_and_1st',
        ip='192.0.2.10',  # Example IP
        events='main_1st_events.csv',
        cycle_length=120,
        cycle_offset=0,  # Reference signal
    ),
    sr.SignalConfig(
        device_id='main_and_2nd',
        ip='192.0.2.11',  # Example IP
        events='main_2nd_events.csv',
        cycle_length=120,
        cycle_offset=30,  # 30 seconds offset from reference
    ),
]

config = sr.SimulationConfig(
    signals=signals,
    simulation_replays=5,
    db_path='./coordinated_test.duckdb'
)

sim = sr.ATCSimulation(config, debug=True)
results = sim.run()
```

### Using `limit_minutes` and `buffer_minutes`

When you only want to replay recent events (e.g., around a known failure time):

```python
signal = sr.SignalConfig(
    device_id='test_signal',
    ip='127.0.0.1',
    udp_port=1025,
    events='full_day_events.csv',
    limit_minutes=30,    # Only replay last 30 minutes
    buffer_minutes=5,    # Include 5 minutes before for detector context
)
```

This replays events from the last 35 minutes of the file, but only the final 30 minutes count toward the actual simulation — the first 5 minutes provide lead-in detector states.

### Quick Run Helper

For simpler use cases without explicit config objects:

```python
import signal_replay as sr

results = sr.quick_run(
    signals=[{
        'device_id': 'signal_1',
        'ip': '127.0.0.1',
        'udp_port': 1025,
        'events': 'events.csv',
    }],
    simulation_replays=3,
    debug=True
)
```

## Event Data Format

Input events should have these columns (flexible naming):

| Column | Alternative Names | Description |
|--------|-------------------|-------------|
| timestamp | `TimeStamp`, `time` | Event timestamp |
| event_id | `EventId`, `EventTypeID` | Event type code |
| parameter | `Parameter`, `Detector` | Event parameter (detector number, phase, etc.) |
| device_id | `DeviceId` | Optional — added automatically if not present |

## Accessing Results

```python
sim = sr.ATCSimulation(config)
results = sim.run()

# Get collected output events
events_df = sim.get_events(device_id='intersection_1', run_number=1)

# Get detected conflicts
conflicts_df = sim.get_conflicts()

# Get comparison summary
print(sim.get_comparison_summary())

# Get original input events
input_df = sim.get_input_events(device_id='intersection_1')
```

<details>
<summary><strong>Database Schema</strong></summary>

Results are stored in DuckDB and can be queried directly for custom analysis.

### Tables

**`events`** — Output events collected from controllers during replay

| Column | Type | Description |
|--------|------|-------------|
| device_id | VARCHAR | Device identifier |
| run_number | INTEGER | Simulation run number |
| timestamp | TIMESTAMP | Event timestamp |
| event_id | INTEGER | Event type code |
| parameter | INTEGER | Event parameter |

**`conflicts`** — Detected phase/overlap conflicts

| Column | Type | Description |
|--------|------|-------------|
| device_id | VARCHAR | Device identifier |
| run_number | INTEGER | Simulation run number |
| timestamp | TIMESTAMP | When conflict occurred |
| conflict_details | VARCHAR | Description (e.g., "Ph1 & Ph5") |

**`input_events`** — Source events used for comparison

| Column | Type | Description |
|--------|------|-------------|
| device_id | VARCHAR | Device identifier |
| timestamp | TIMESTAMP | Event timestamp |
| event_id | INTEGER | Event type code |
| parameter | INTEGER | Event parameter |

### Example Query

Find all conflicts grouped by type:

```python
import duckdb

con = duckdb.connect('./results.duckdb')

conflicts_by_type = con.execute("""
    SELECT 
        conflict_details,
        COUNT(*) as occurrences,
        MIN(timestamp) as first_occurrence,
        MAX(timestamp) as last_occurrence
    FROM conflicts
    GROUP BY conflict_details
    ORDER BY occurrences DESC
""").df()

print(conflicts_by_type)
```

Example output:

| conflict_details | occurrences | first_occurrence | last_occurrence |
|------------------|-------------|------------------|-----------------|
| Ph1 & Ph5 | 3 | 2025-01-15 14:23:01 | 2025-01-15 14:45:12 |
| O1 & Ph6 | 1 | 2025-01-15 14:30:45 | 2025-01-15 14:30:45 |

</details>

## Compatibility

- **Reading events**: Currently supports MAXTIME controllers. Other controllers can be added.
- **Sending actuations**: Works with any ATC controller supporting NTCIP 1202 v3.

## License

MIT License — see [LICENSE](LICENSE) for details.
